﻿// Set paths to HITRAN's *.par and TIPS files
//
int const
	path_len_max = 256;
char const
	path_hitdb[path_len_max] = "./hitran/",
	path_TIPS[path_len_max] = "./hitran/TIPS/";
//
/*------------------------------------------------------------------------------------------------*/