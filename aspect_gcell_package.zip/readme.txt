For instructions see Sec.3 in
S.Korkin, A.M.Sayer, A.Ibrahim, and A. Lyapustin:
"A practical guide to coding line-by-line trace gas absorption in Earth�s atmosphere"
2023/24 (in preparation)
doi: N/A